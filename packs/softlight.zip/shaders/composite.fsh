#version 120

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0;
uniform sampler2D noisetex;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float isEyeInWater;
uniform float SL_shadowRes;

varying vec2 texcoord;


const vec3 SL_DAY_ZEN = vec3(0.13, 0.31, 0.71);
const vec3 SL_DAY_HOR = vec3(0.61, 0.75, 0.92);
const vec3 SL_NGT_ZEN = vec3(0.006, 0.010, 0.028);
const vec3 SL_NGT_HOR = vec3(0.028, 0.045, 0.095);
const vec3 SL_SUNSET  = vec3(1.00, 0.40, 0.14);

float slDayF(vec3 sunDir) { return smoothstep(-0.07, 0.16, sunDir.y); }

vec3 slSky(vec3 dir, vec3 sunDir, float rain) {
  float d = slDayF(sunDir);
  float sunsetF = exp(-abs(sunDir.y) * 11.0);
  float upness = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
  vec3 zen = mix(SL_NGT_ZEN, SL_DAY_ZEN, d);
  vec3 hor = mix(SL_NGT_HOR, SL_DAY_HOR, d);
  vec3 col = mix(hor, zen, pow(upness, 0.55));
  vec2 sxz = normalize(sunDir.xz + vec2(0.00001));
  vec2 dxz = normalize(dir.xz + vec2(0.00001));
  float az = dot(sxz, dxz) * 0.5 + 0.5;
  col += SL_SUNSET * sunsetF * pow(az, 3.0) * pow(1.0 - abs(dir.y), 4.0) * 1.4;
  float lum = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(col, vec3(lum) * 0.42, rain * 0.85);
  col *= 1.0 - rain * 0.35;
  return col;
}

vec3 slStars(vec3 dir, float time) {
  vec3 p = dir * 180.0;
  vec3 c = floor(p);
  float h = fract(sin(dot(c, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
  vec3 f = fract(p) - 0.5;
  float star = smoothstep(0.30, 0.05, length(f)) * step(0.996, h);
  float tw = 0.6 + 0.4 * sin(time * 2.0 + h * 40.0);
  return vec3(star * tw);
}

vec3 slSunDisc(vec3 dir, vec3 sunDir) {
  float c = dot(dir, sunDir);
  float disc = smoothstep(0.99935, 0.99965, c);
  vec3 tint = mix(vec3(1.0, 0.45, 0.18), vec3(1.0, 0.92, 0.78), smoothstep(0.0, 0.35, sunDir.y));
  float glow = pow(max(c, 0.0), 200.0) * 0.5 + pow(max(c, 0.0), 12.0) * 0.05;
  return tint * (disc * 6.0 + glow) * smoothstep(-0.06, 0.02, sunDir.y);
}

vec3 slMoonDisc(vec3 dir, vec3 sunDir, float nightD) {
  vec3 md = -sunDir;
  float c = dot(dir, md);
  float disc = smoothstep(0.99955, 0.99975, c);
  return vec3(0.85, 0.90, 1.0) * (disc * 1.6 + pow(max(c, 0.0), 280.0) * 0.25) * nightD * smoothstep(-0.06, 0.02, md.y);
}

vec4 slClouds(vec3 dir, vec3 camPos, vec3 sunDir, float time, float rain, float d) {
  float ch = 176.0 - camPos.y;
  if (dir.y < 0.02 || ch <= 0.0) return vec4(0.0);
  float t = ch / dir.y;
  vec2 uv = (camPos.xz + dir.xz * t) * 0.0035 + vec2(time * 0.006, time * 0.002);
  float f = texture2D(noisetex, uv).r * 0.5;
  f += texture2D(noisetex, uv * 2.7 + vec2(0.31, 0.17)).r * 0.25;
  f += texture2D(noisetex, uv * 6.1 + vec2(0.77, 0.53)).r * 0.15;
  f += texture2D(noisetex, uv * 13.9).r * 0.10;
  float cov = smoothstep(0.52 - rain * 0.24, 0.78, f);
  float fade = smoothstep(9000.0, 1500.0, t) * smoothstep(0.02, 0.09, dir.y);
  vec3 cc = mix(vec3(0.03, 0.04, 0.06), vec3(0.90, 0.93, 0.97), d);
  float sunsetF = exp(-abs(sunDir.y) * 11.0);
  cc = mix(cc, SL_SUNSET * 1.15, sunsetF * 0.45);
  cc *= 1.0 - rain * 0.55;
  return vec4(cc, cov * fade * 0.9);
}


float slShadow(vec3 worldPos, vec3 cameraPosition, float NdotL) {
  vec4 shc = shadowProjection * shadowModelView * vec4(worldPos - cameraPosition, 1.0);
  shc.xy /= mix(1.0, length(shc.xy), 0.85);
  vec3 suv = shc.xyz * 0.5 + 0.5;
  if (suv.x <= 0.002 || suv.x >= 0.998 || suv.y <= 0.002 || suv.y >= 0.998 || suv.z >= 1.0) return 1.0;
  float bias = 0.00055 + clamp(tan(acos(clamp(NdotL, 0.0, 1.0))), 0.0, 2.5) * 0.0007;
  float texel = 1.0 / SL_shadowRes;
  float sum = 0.0;
  for (int x = -1; x <= 1; x++) {
    for (int y = -1; y <= 1; y++) {
      float d = texture2D(shadowtex0, suv.xy + vec2(float(x), float(y)) * texel).r;
      sum += step(suv.z - bias, d);
    }
  }
  return sum / 9.0;
}

void main() {
  vec2 uv = texcoord;
  float depth = texture2D(depthtex0, uv).x;
  vec4 col0 = texture2D(colortex0, uv);

  if (depth >= 1.0) {
    gl_FragData[0] = col0;
    return;
  }

  vec4 ndc = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
  vec4 vp4 = gbufferProjectionInverse * ndc;
  vec3 viewPos = vp4.xyz / vp4.w;
  vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;

  vec4 nrmData = texture2D(colortex1, uv);
  vec3 nW = normalize(mat3(gbufferModelViewInverse) * (normalize(nrmData.xyz * 2.0 - 1.0)));
  float material = nrmData.a * 255.0;
  vec2 lmRaw = texture2D(colortex2, uv).xy;
  vec2 lm = clamp((lmRaw - 0.03125) / 0.9375, 0.0, 1.0);
  vec3 matP = texture2D(colortex3, uv).rgb;

  vec3 sunDirW = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
  float dayF = slDayF(sunDirW);
  float nightF = 1.0 - dayF;
  vec3 lightDirW = normalize(mat3(gbufferModelViewInverse) * normalize(shadowLightPosition));

  vec3 albedo = pow(col0.rgb, vec3(2.2));
  vec3 viewDirW = normalize(worldPos - cameraPosition);
  float NdotL = dot(nW, lightDirW);

  // 太陽光
  vec3 sunTint = mix(vec3(1.0, 0.42, 0.16), vec3(1.0, 0.94, 0.86), smoothstep(0.02, 0.33, sunDirW.y));
  vec3 sunCol = sunTint * dayF * 2.0 * (1.0 - rainStrength * 0.85);
  vec3 moonCol = vec3(0.10, 0.13, 0.22) * nightF * (1.0 - rainStrength * 0.8);

  float shadow = material > 215.0 ? 1.0 : slShadow(worldPos, cameraPosition, max(NdotL, 0.0));
  shadow *= 1.0 - rainStrength * 0.35;

  // 環境光 (半球)
  vec3 skyAmb = mix(vec3(0.016, 0.022, 0.045), vec3(0.34, 0.42, 0.54), dayF) * (1.0 - rainStrength * 0.55);
  vec3 gndAmb = vec3(0.06, 0.05, 0.04) * dayF;
  vec3 ambient = mix(gndAmb, skyAmb, nW.y * 0.5 + 0.5) * (0.25 + 0.75 * lm.y);
  vec3 torch = vec3(1.0, 0.55, 0.24) * pow(lm.x, 2.4) * 1.5;

  vec3 direct = sunCol * max(NdotL, 0.0) * shadow;
  direct += moonCol * max(NdotL, 0.0) * shadow;

  vec3 color = albedo * (ambient + torch) + albedo * direct;

  // 草花は少し明るく (トゥーン補正)
  if (material > 130.0 && material < 150.0) color += albedo * skyAmb * 0.25 * lm.y;

  // 発光ブロック
  if (material > 215.0) color = albedo * 4.5 + albedo * ambient * 0.3;

  // 鏡面反射
  float smoothness = matP.r;
  if (smoothness > 0.2 && dayF * max(NdotL, 0.0) * shadow > 0.0) {
    vec3 h = normalize(lightDirW - viewDirW);
    float spec = pow(max(dot(nW, h), 0.0), 40.0) * smoothness;
    color += sunTint * dayF * spec * shadow * 0.7;
  }

  // 水: フレネル反射
  if (material > 190.0 && material < 210.0) {
    vec3 refl = reflect(viewDirW, nW);
    refl.y = abs(refl.y) * 0.98 + 0.02;
    vec3 skyRef = slSky(normalize(refl), sunDirW, rainStrength);
    skyRef += slSunDisc(normalize(refl), sunDirW) * 0.08;
    float fres = 0.03 + 0.97 * pow(1.0 - max(dot(-viewDirW, nW), 0.0), 5.0);
    vec3 deep = albedo * (ambient + torch) * 0.8 + moonCol * 0.2 * max(NdotL, 0.0);
    color = mix(deep, skyRef, fres * 0.92);
    vec3 hw = normalize(lightDirW - viewDirW);
    color += sunTint * dayF * pow(max(dot(nW, hw), 0.0), 180.0) * shadow * 1.2;
    color += vec3(0.10, 0.13, 0.22) * nightF * pow(max(dot(nW, normalize(-sunDirW - viewDirW)), 0.0), 160.0);
  }

  // 雨: 濡れた地面
  float wet = rainStrength * step(0.5, 1.0 - material * 0.004);
  color *= 1.0 - wet * 0.22;

  // 霧
  float dist = length(viewPos);
  vec3 fogDir = viewDirW;
  vec3 fogCol = slSky(normalize(vec3(fogDir.x, max(fogDir.y, -0.03), fogDir.z)), sunDirW, rainStrength);
  float fogDensity = (1.0 / 115.0) * (1.0 + rainStrength * 2.2);
  float fogF = 1.0 - exp(-dist * fogDensity);
  fogF = pow(fogF, 1.4);
  color = mix(color, fogCol, clamp(fogF, 0.0, 1.0));

  // 水中
  if (isEyeInWater > 0.5) {
    float wf = exp(-dist * 0.10);
    color = mix(vec3(0.02, 0.10, 0.16), color, wf);
  }

  gl_FragData[0] = vec4(color, 1.0);
}
