#version 120

uniform sampler2D colortex0;
uniform vec2 texelSize;

varying vec2 texcoord;

void main() {
  vec3 c = vec3(0.0);
  c += texture2D(colortex0, texcoord + texelSize * vec2(-1.0, -1.0)).rgb;
  c += texture2D(colortex0, texcoord + texelSize * vec2( 1.0, -1.0)).rgb;
  c += texture2D(colortex0, texcoord + texelSize * vec2(-1.0,  1.0)).rgb;
  c += texture2D(colortex0, texcoord + texelSize * vec2( 1.0,  1.0)).rgb;
  c *= 0.25;
  gl_FragData[0] = vec4(max(c - 0.62, 0.0) * 1.5, 1.0);
}
