#version 120

uniform sampler2D colortex0;
uniform vec2 texelSize;

varying vec2 texcoord;

void main() {
  vec2 off = vec2(texelSize.x * 2.2, 0.0);
  vec3 sum = texture2D(colortex0, texcoord).rgb * 0.196;
  float w[3]; w[0] = 0.174; w[1] = 0.121; w[2] = 0.054;
  for (int i = 1; i <= 2; i++) {
    float fi = float(i);
    sum += texture2D(colortex0, texcoord + off * fi).rgb * w[i];
    sum += texture2D(colortex0, texcoord - off * fi).rgb * w[i];
  }
  gl_FragData[0] = vec4(sum, 1.0);
}
