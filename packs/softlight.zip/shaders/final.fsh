#version 120

uniform sampler2D colortex0;
uniform sampler2D noisetex;
uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float SL_lightningFlash;

varying vec2 texcoord;

vec3 slToneMap(vec3 x) {
  x *= 1.05;
  vec3 a = x * (2.51 * x + 0.03);
  vec3 b = x * (2.43 * x + 0.59) + 0.14;
  return clamp(a / b, 0.0, 1.0);
}

void main() {
  vec3 color = texture2D(colortex0, texcoord).rgb;
  vec3 sunDirW = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
  float dayF = smoothstep(-0.07, 0.16, sunDirW.y);

  // 露光 (夜は少し持ち上げ)
  float exposure = mix(1.45, 1.0, dayF);
  color = slToneMap(color * exposure);

  // 雨の筋
  if (rainStrength > 0.01) {
    float aspect = viewWidth / max(viewHeight, 1.0);
    vec2 suv = vec2(texcoord.x * aspect, texcoord.y);
    float ca = 0.22, sa = 0.975;
    vec2 ruv = vec2(suv.x * ca - suv.y * sa, suv.x * sa + suv.y * ca);
    float line = fract(ruv.x * 110.0 + texture2D(noisetex, vec2(ruv.x * 1.5, ruv.y * 0.25 - frameTimeCounter * 0.7)).r * 7.0);
    float streak = smoothstep(0.965, 1.0, line) * texture2D(noisetex, vec2(ruv.x * 110.0, ruv.y * 0.9 - frameTimeCounter * 2.6)).r;
    float verticalMask = smoothstep(1.05, 0.25, suv.y);
    color += streak * verticalMask * rainStrength * 0.30 * vec3(0.65, 0.75, 0.95);
  }

  // 雷
  color += vec3(0.85, 0.92, 1.10) * SL_lightningFlash * 0.75;

  // ビネット
  vec2 vc = texcoord - 0.5;
  color *= 1.0 - dot(vc, vc) * 0.55 * (1.0 - dayF * 0.35);

  color = pow(clamp(color, 0.0, 1.0), vec3(1.0 / 2.2));
  gl_FragData[0] = vec4(color, 1.0);
}
