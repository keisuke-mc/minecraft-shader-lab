#version 120

varying vec2 texcoord;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform vec3 cameraPosition;
uniform sampler2D noisetex;


const vec3 SL_DAY_ZEN = vec3(0.13, 0.31, 0.71);
const vec3 SL_DAY_HOR = vec3(0.61, 0.75, 0.92);
const vec3 SL_NGT_ZEN = vec3(0.006, 0.010, 0.028);
const vec3 SL_NGT_HOR = vec3(0.028, 0.045, 0.095);
const vec3 SL_SUNSET  = vec3(1.00, 0.40, 0.14);

float slDayF(vec3 sunDir) { return smoothstep(-0.07, 0.16, sunDir.y); }

vec3 slSky(vec3 dir, vec3 sunDir, float rain) {
  float d = slDayF(sunDir);
  float sunsetF = exp(-abs(sunDir.y) * 11.0);
  float upness = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
  vec3 zen = mix(SL_NGT_ZEN, SL_DAY_ZEN, d);
  vec3 hor = mix(SL_NGT_HOR, SL_DAY_HOR, d);
  vec3 col = mix(hor, zen, pow(upness, 0.55));
  vec2 sxz = normalize(sunDir.xz + vec2(0.00001));
  vec2 dxz = normalize(dir.xz + vec2(0.00001));
  float az = dot(sxz, dxz) * 0.5 + 0.5;
  col += SL_SUNSET * sunsetF * pow(az, 3.0) * pow(1.0 - abs(dir.y), 4.0) * 1.4;
  float lum = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(col, vec3(lum) * 0.42, rain * 0.85);
  col *= 1.0 - rain * 0.35;
  return col;
}

vec3 slStars(vec3 dir, float time) {
  vec3 p = dir * 180.0;
  vec3 c = floor(p);
  float h = fract(sin(dot(c, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
  vec3 f = fract(p) - 0.5;
  float star = smoothstep(0.30, 0.05, length(f)) * step(0.996, h);
  float tw = 0.6 + 0.4 * sin(time * 2.0 + h * 40.0);
  return vec3(star * tw);
}

vec3 slSunDisc(vec3 dir, vec3 sunDir) {
  float c = dot(dir, sunDir);
  float disc = smoothstep(0.99935, 0.99965, c);
  vec3 tint = mix(vec3(1.0, 0.45, 0.18), vec3(1.0, 0.92, 0.78), smoothstep(0.0, 0.35, sunDir.y));
  float glow = pow(max(c, 0.0), 200.0) * 0.5 + pow(max(c, 0.0), 12.0) * 0.05;
  return tint * (disc * 6.0 + glow) * smoothstep(-0.06, 0.02, sunDir.y);
}

vec3 slMoonDisc(vec3 dir, vec3 sunDir, float nightD) {
  vec3 md = -sunDir;
  float c = dot(dir, md);
  float disc = smoothstep(0.99955, 0.99975, c);
  return vec3(0.85, 0.90, 1.0) * (disc * 1.6 + pow(max(c, 0.0), 280.0) * 0.25) * nightD * smoothstep(-0.06, 0.02, md.y);
}

vec4 slClouds(vec3 dir, vec3 camPos, vec3 sunDir, float time, float rain, float d) {
  float ch = 176.0 - camPos.y;
  if (dir.y < 0.02 || ch <= 0.0) return vec4(0.0);
  float t = ch / dir.y;
  vec2 uv = (camPos.xz + dir.xz * t) * 0.0035 + vec2(time * 0.006, time * 0.002);
  float f = texture2D(noisetex, uv).r * 0.5;
  f += texture2D(noisetex, uv * 2.7 + vec2(0.31, 0.17)).r * 0.25;
  f += texture2D(noisetex, uv * 6.1 + vec2(0.77, 0.53)).r * 0.15;
  f += texture2D(noisetex, uv * 13.9).r * 0.10;
  float cov = smoothstep(0.52 - rain * 0.24, 0.78, f);
  float fade = smoothstep(9000.0, 1500.0, t) * smoothstep(0.02, 0.09, dir.y);
  vec3 cc = mix(vec3(0.03, 0.04, 0.06), vec3(0.90, 0.93, 0.97), d);
  float sunsetF = exp(-abs(sunDir.y) * 11.0);
  cc = mix(cc, SL_SUNSET * 1.15, sunsetF * 0.45);
  cc *= 1.0 - rain * 0.55;
  return vec4(cc, cov * fade * 0.9);
}


void main() {
  vec4 ndc = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
  vec4 v = gbufferProjectionInverse * ndc;
  vec3 viewDir = normalize(v.xyz / v.w);
  vec3 dir = normalize(mat3(gbufferModelViewInverse) * viewDir);
  vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
  float d = slDayF(sunDir);
  float nightD = 1.0 - d;
  vec3 col = slSky(dir, sunDir, rainStrength);
  col += slStars(dir, frameTimeCounter) * nightD * (1.0 - rainStrength);
  col += slSunDisc(dir, sunDir);
  col += slMoonDisc(dir, sunDir, nightD);
  vec4 cl = slClouds(dir, cameraPosition, sunDir, frameTimeCounter, rainStrength, d);
  col = mix(col, cl.rgb, cl.a);
  gl_FragData[0] = vec4(col, 1.0);
}
