#version 120

uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying float matId;

void main() {
  vec4 albedo = texture2D(gtexture, texcoord) * color;
  if (albedo.a < 0.1) discard;

  float mat = 0.0;
  float smoothness = 0.05;
  float metallic = 0.0;
  float emissive = 0.0;

  if (matId > 5.5 && matId < 6.5) { mat = 160.0; smoothness = 0.08; }
  if (matId > 7.5 && matId < 8.5) { mat = 220.0; emissive = 1.0; }
  if (matId > 9.5) { mat = 140.0; smoothness = 0.10; }

  gl_FragData[0] = vec4(albedo.rgb, 1.0);
  gl_FragData[1] = vec4(normal * 0.5 + 0.5, mat / 255.0);
  gl_FragData[2] = vec4(lmcoord, 0.0, 1.0);
  gl_FragData[3] = vec4(smoothness, metallic, emissive, 1.0);
}
