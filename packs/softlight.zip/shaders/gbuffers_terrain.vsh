#version 120

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying float matId;

attribute vec4 mc_Entity;

void main() {
  gl_Position = ftransform();
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  color = gl_Color;
  normal = gl_NormalMatrix * gl_Normal;
  matId = mc_Entity.x;
}
