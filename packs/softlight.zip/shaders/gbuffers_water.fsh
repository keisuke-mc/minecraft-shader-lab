#version 120

uniform sampler2D gtexture;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 worldPos;

void main() {
  vec4 albedo = texture2D(gtexture, texcoord) * color;
  vec3 n = normalize(normal);
  float rip1 = sin(worldPos.x * 2.3 + frameTimeCounter * 2.4 + sin(worldPos.z * 1.4 + frameTimeCounter * 1.3) * 1.5);
  float rip2 = cos(worldPos.z * 2.6 + frameTimeCounter * 1.9 + sin(worldPos.x * 1.7 + frameTimeCounter * 0.9) * 1.3);
  n = normalize(n + vec3(rip1, 0.0, rip2) * 0.12);
  gl_FragData[0] = vec4(albedo.rgb, albedo.a);
  gl_FragData[1] = vec4(n * 0.5 + 0.5, 200.0 / 255.0);
  gl_FragData[2] = vec4(lmcoord, 0.0, 1.0);
  gl_FragData[3] = vec4(0.9, 0.0, 0.0, 1.0);
}
