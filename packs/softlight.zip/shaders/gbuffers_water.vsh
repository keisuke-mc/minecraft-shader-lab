#version 120

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 normal;
varying vec3 worldPos;

attribute vec4 mc_Entity;

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

void main() {
  vec4 pos = gl_Vertex;
  worldPos = (gbufferModelViewInverse * (gl_ModelViewMatrix * pos)).xyz + cameraPosition;
  float wave = sin(worldPos.x * 0.9 + frameTimeCounter * 2.1) * cos(worldPos.z * 0.8 + frameTimeCounter * 1.7) * 0.045;
  pos.y += wave;
  gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * pos;
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  color = gl_Color;
  normal = gl_NormalMatrix * gl_Normal;
}
