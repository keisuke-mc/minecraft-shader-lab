#version 120

uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec4 color;
varying float matId;

void main() {
  vec4 albedo = texture2D(gtexture, texcoord) * color;
  if (albedo.a < 0.1) discard;
  gl_FragData[0] = albedo;
  gl_FragData[1] = vec4(1.0);
}
