#version 120

varying vec2 texcoord;
varying vec4 color;
varying float matId;

attribute vec4 mc_Entity;

void main() {
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  color = gl_Color;
  matId = mc_Entity.x;
  gl_Position = ftransform();
  gl_Position.xy /= mix(1.0, length(gl_Position.xy), 0.85);
}
