#version 120

varying vec2 texcoord;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;

void main() {
  vec4 ndc = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
  vec4 v = gbufferProjectionInverse * ndc;
  vec3 dir = normalize(mat3(gbufferModelViewInverse) * normalize(v.xyz / v.w));
  vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
  float dayF = smoothstep(-0.14, 0.22, sunDir.y);
  float sunsetF = exp(-abs(sunDir.y) * 9.0);
  vec3 zen = mix(vec3(0.008, 0.012, 0.030), vec3(0.29, 0.48, 0.80), dayF);
  vec3 hor = mix(vec3(0.03, 0.04, 0.08), vec3(0.68, 0.80, 0.92), dayF);
  vec3 col = mix(hor, zen, pow(clamp(dir.y * 0.5 + 0.5, 0.0, 1.0), 0.6));
  vec2 sxz = normalize(sunDir.xz + vec2(0.00001));
  vec2 dxz = normalize(dir.xz + vec2(0.00001));
  float az = dot(sxz, dxz) * 0.5 + 0.5;
  col += vec3(1.0, 0.5, 0.2) * sunsetF * pow(az, 3.0) * pow(1.0 - abs(dir.y), 4.0);
  float lum = dot(col, vec3(0.3, 0.6, 0.1));
  col = mix(col, vec3(lum) * 0.5, rainStrength * 0.8);
  gl_FragData[0] = vec4(col, 1.0);
}
