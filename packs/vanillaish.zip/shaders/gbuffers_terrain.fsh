#version 120

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying float dist;

void main() {
  vec4 albedo = texture2D(gtexture, texcoord) * color;
  if (albedo.a < 0.1) discard;

  vec3 sunDir = normalize(sunPosition);
  float dayF = smoothstep(-0.14, 0.22, sunDir.y);
  float skyBr = mix(0.22, 1.0, dayF) * (1.0 - rainStrength * 0.4);
  float torchBr = pow(clamp((lmcoord.x - 0.03125) / 0.9375, 0.0, 1.0), 2.0);
  float skyLm = clamp((lmcoord.y - 0.03125) / 0.9375, 0.0, 1.0);

  vec3 light = vec3(1.0, 0.6, 0.3) * torchBr * 1.1;
  light += vec3(0.8, 0.9, 1.0) * skyLm * skyBr;

  vec3 col = albedo.rgb * light;

  float fogF = 1.0 - exp(-dist * (1.0 / 110.0) * (1.0 + rainStrength * 2.0));
  col = mix(col, fogColor, clamp(fogF, 0.0, 1.0));

  gl_FragData[0] = vec4(col, albedo.a);
}
