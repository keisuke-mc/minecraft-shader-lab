#version 120

uniform sampler2D gtexture;
uniform vec3 fogColor;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying float dist;

void main() {
  vec4 albedo = texture2D(gtexture, texcoord) * color;
  vec3 col = albedo.rgb * vec3(0.7, 0.85, 1.05);
  float fogF = 1.0 - exp(-dist * (1.0 / 110.0) * (1.0 + rainStrength * 2.0));
  col = mix(col, fogColor, clamp(fogF, 0.0, 1.0));
  gl_FragData[0] = vec4(col, albedo.a);
}
