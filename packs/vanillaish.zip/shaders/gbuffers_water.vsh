#version 120

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying float dist;

void main() {
  gl_Position = ftransform();
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  color = gl_Color;
  vec4 wp = gl_ModelViewMatrix * gl_Vertex;
  dist = length(wp.xyz);
}
